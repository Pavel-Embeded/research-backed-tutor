# Teaching guide

Use this reference to turn the checked knowledge map into a complete beginner guide. The goal is understanding that transfers to new problems, not an impressive volume of facts.

Read [understanding-design.md](understanding-design.md) for every substantive lesson. First-time instruction must expose the path from a motivated problem through taught premises and justified steps to a checked result. A conclusion-dense summary, glossary or comparison table is a review aid; it cannot substitute for that path. Respect an explicit request for review or brevity without claiming the full teaching gates have passed.

Read and apply [plain-language.md](plain-language.md) when writing or revising. Assume the reader has no knowledge of the field, including its terms, symbols, diagrams, methods, and tools. Explain each necessary prerequisite before use. Prefer concrete everyday language, clear subjects, and small connected steps; preserve exact conditions and technical accuracy. Every final sentence and non-sentence expression unit needs its own simulated-beginner check and restatement evidence. This includes headings, tables, diagrams, formulas, code, commands, exercises, answers, and the final check summary. Paragraph sampling and a general claim of readability do not meet this requirement.

## Build the logical chain

1. State the learner's goal and show a small map of where the topic sits in the larger field. Introduce only prerequisites that later reasoning actually uses.
2. Explain the real problem or historical setting that motivated the idea. Separate sourced history from a simplified teaching story.
3. Give a plain-language intuition, then precise terms and boundaries. For every new symbol, rule, or mechanism, show the need it answers and what would fail without it.
4. Derive or explain each main point in small steps: known premise, purpose of this step, justified operation or observation, inference, assumption, and consequence. For a mathematical topic, show intermediate algebra and units; for code, trace input, state, output, and failure cases; for a humanities topic, trace evidence, interpretation, and competing views. Explain what connects adjacent steps: a label such as “damping” does not establish why a parameter changes the observed behavior.
5. Work one concrete example through method choice, steps, verification and interpretation; follow it with a completion task and an independent changed case. Change one factor where practical and ask for a prediction before calculating. Include a change that tests the reasoning or method choice, not only arithmetic. Use analogies to help entry, then say exactly where each analogy breaks.
6. Compare nearby and easily confused concepts using the same dimensions. Explain typical wrong answers and why they fail.
7. Show practical uses and then zoom back out: how the parts connect, which ideas generalize, and what remains an open question.

Introduce a small map with explained labels before expanding to the complete network. Show how to read symbols, arrows, and code before relying on them. Put detailed sources and check records where the reader can consult them without interrupting the main learning path. This changes presentation order, not the scope or completion gates. Do not attach a role-play dialogue or a quiz after every sentence; perform the exhaustive checks during the task and present the repaired lesson naturally.

Use diagrams or interactive visuals when they reveal a relationship that prose obscures. Keep terminology consistent across the map, examples, exercises, and answer key. Cite sources beside claims that depend on external evidence; do not cite a repository or blog for a claim it does not establish. Attribute an expert's explanation to its actual lecture or writing, not merely to their reputation. Paraphrase protected material and quote sparingly.

## Default deliverable

Before releasing a complete result, run [mastery-loop.md](mastery-loop.md). Questions and incorrect simulated-learner outputs must revise the explanation itself, followed by fresh checks. Include [investigation-guide.md](investigation-guide.md)'s typed knowledge network and [project-lab.md](project-lab.md)'s independent project. A self-test attached to a lesson does not satisfy these completion gates.

- Learning objective, assumed starting point, and prerequisite map.
- Background and problem; first-principles explanation with stepwise derivations.
- At least one simple and one transfer example for each central mechanism; analogies with limitations.
- A comparison of confusing concepts, common mistakes, and real applications.
- A whole-system summary that reconnects the detailed pieces.
- Exercises that check recall, explanation, application, and diagnosis of a mistaken approach, followed by fully worked answers and self-check criteria.
- A concept-to-source table, concise search coverage record, remaining gaps, and any important disagreements.
- A scope-complete node inventory, typed edge table, hand-drawing reconstruction instructions, and the learner's checked reconstruction artifact.
- An independently constructed project with requirement-to-concept traceability, actual applicable validation evidence, and a concise simulation-check report. Unmet required gates must remain explicitly failed or unverified.

Adapt quantities to the topic rather than filling sections mechanically. Do not replace the derivation with an analogy or a list of conclusions. Do not state that mastery has been achieved solely because the guide is complete. If the learner answers a check incorrectly, locate the missing prerequisite or inference, reteach it with a new example, and reassess with a different problem.
